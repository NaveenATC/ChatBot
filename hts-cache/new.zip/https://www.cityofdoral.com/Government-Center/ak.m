<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en-US">
<!--<![endif]-->
<head>
	<!-- Published by OpenCities, 1.37.2.0 -->

    
        
    
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="theme-color" content="#FFFFFF"/>
    <title>Page Not Found - City of Doral</title>
	<meta name="generator" content="OpenCities - https://granicus.com/product/opencities" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Using mobile-web-app-capable for now to enable full-screen experience on supported platforms -->
    <!-- Note: This tag works mainly on Android Chrome. It does NOT enable full-screen mode on iOS Safari. -->
    <!-- For iOS, the correct tag is: <meta name="apple-mobile-web-app-capable" content="yes"> -->
    <!-- TODO: Monitor for updated meta tag standards from Apple or other browser vendors -->
    <meta name="mobile-web-app-capable" content="yes" />
        <meta name="description" content="Page not found error" />
    <meta property="og:type" content="article" />
    <meta property="og:url" content="https://www.cityofdoral.com/Page-Not-Found" />
    <meta property="og:title" content="Page Not Found" />
    <meta property="og:description" content="Page not found error" />
    <meta property="og:image" content="https://www.cityofdoral.com/files/ocwebsite/City/HeroImage/gov-center-meta-data.jpg?w=1200" />
    <meta property="twitter:card" content="summary" />
    <meta property="twitter:title" content="Page Not Found" />
    <meta property="twitter:description" content="Page not found error" />
    <meta property="twitter:image" content="https://www.cityofdoral.com/files/ocwebsite/City/HeroImage/gov-center-meta-data.jpg?w=1080" />
    <link rel="canonical" href="https://www.cityofdoral.com/Page-Not-Found" />

    
    <link rel="apple-touch-icon" sizes="180x180" href="/files/ocfavicon/City/apple-touch-icon.png?V=638544819997875641">
<link rel="icon" type="image/png" sizes="32x32" href="/files/ocfavicon/City/favicon-32x32.png?V=638544819997875641">
<link rel="icon" type="image/png" sizes="16x16" href="/files/ocfavicon/City/favicon-16x16.png?V=638544819997875641">
<link rel="manifest" href="/files/ocfavicon/City/site.webmanifest?V=638544819997875641">
<link rel="shortcut icon" href="/files/ocfavicon/City/favicon.ico?V=638544819997875641">
<meta name="msapplication-TileColor" content="#000000">
<meta name="msapplication-config" content="/files/ocfavicon/City/browserconfig.xml?V=638544819997875641">

    <!-- Preconnecting to Google Fonts servers -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <!-- Defer Roboto font loading to avoid render-blocking -->
    <script>
        window.addEventListener('DOMContentLoaded', () => {
            const robotoLink = document.createElement('link');
            robotoLink.rel = 'stylesheet';
            robotoLink.href = 'https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap';
            document.head.appendChild(robotoLink);
        });
    </script>

    <style>
        .gm-style, .gm-style * {
            font-family: 'Roboto', system-ui, -apple-system, "Segoe UI", Arial, sans-serif !important;
        }
    </style>

    <script>
        document.documentElement.className = document.documentElement.className.replace(/\bno-js\b/g, "js");
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0" />
    
        
            <script type="text/javascript">
                window.__oc_flags_ImprovedBreakpointEventHandling = true;
            </script>
            
        
    
    
    
        <script type="text/javascript">
            var __metaQueryBreakpoints = {
                'sc-size-4': '(max-width: 480px)',
                'sc-size-3': '(min-width: 480px) and (max-width: 768px)',
                'sc-size-2': '(min-width: 768px) and (max-width: 992px)',
                'sc-size-1': '(min-width: 992px)'
            }

            var __ocSizePoints = [
                { min: 0, name: 'sc-size-4' },
                { min: 480, name: 'sc-size-3' },
                { min: 768, name: 'sc-size-2' },
                { min: 992, name: 'sc-size-1' }
            ];

        </script>
    

    <!-- Framework Section -->
    
    <script src="//ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="/files/templates/00000000-0000-0000-0000-000000000000/cb43379f-eba5-4cd1-93a4-8079e117411e/v/249/jquery-3.6.0.min.js?seamlessts=639124142685437828" ><\/script>')</script>

    <!--Google Maps API Loader – Improved Version to avoid Warning
    This script loads the Google Maps JavaScript API using a dynamic and async method.
    It replaces the old static <script> tag to avoid performance warnings from Google.

    Dynamically creates the <script> tag with loading = async for better performance
    Builds the API URL with required libraries(places, geometry, marker, geocoding)
    Uses a Promise and callback(google.maps.__ib__) to confirm when the script is ready

    It Avoids Google’s warning about direct script loading
    Improves page load speed by loading the API asynchronously-->

    
        <script>
            (function (root) {
                root.OpenCities = root.OpenCities || {};
                if (!root.OpenCities.GoogleMapsLoader) {
                    root.OpenCities.GoogleMapsLoader = {
                        _cbs: [],
                        _ready: false,
                        onReady: function (cb) {
                            if (this._ready) { try { cb(); } catch (e) { console.error(e); } }
                            else if (typeof cb === 'function') this._cbs.push(cb);
                        },
                        _fire: function () {
                            if (this._ready) return;
                            this._ready = true;
                            var q = this._cbs.splice(0);
                            for (var i = 0; i < q.length; i++) {
                                try { q[i](); } catch (e) { console.error(e); }
                            }
                        }
                    };
                }
            })(window);

            (g => {
                var h, a, k, p = "The Google Maps JavaScript API", c = "google", l = "importLibrary", q = "__ib__",
                    m = document, b = window;
                b = b[c] || (b[c] = {});
                var d = b.maps || (b.maps = {}), r = new Set, e = new URLSearchParams,
                    u = () => h || (h = new Promise(async (resolve, reject) => {
                        a = m.createElement("script");
                        e.set("libraries", [...r] + "");
                        for (k in g) e.set(k.replace(/[A-Z]/g, t => "_" + t[0].toLowerCase()), g[k]);
                        e.set("callback", c + ".maps." + q);
                        a.src = "https://maps." + c + "apis.com/maps/api/js?" + e.toString();
                        a.loading = "async";
                        a.async = true;
                        a.defer = true;
                        d[q] = resolve;
                        a.onerror = () => reject(Error(p + " could not load."));
                        a.nonce = m.querySelector("script[nonce]")?.nonce || "";
                        m.head.append(a);
                    }));
                if (d[l]) {
                    console.warn(p + " only loads once. Ignoring duplicate load.");
                } else {
                    d[l] = (f, ...n) => (r.add(f), u().then(() => d[l](f, ...n)));
                }
            })({
                key: "AIzaSyBQzxqE-L8izPvhgKKtdD0saSdiIsnUH5s",
                v: "quarterly"
            });

            (async () => {
                try {
                    if (!google?.maps?.importLibrary) return;

                    if (!window.OpenCities.__mapsLibsPromise) {
                        window.OpenCities.__mapsLibsPromise = Promise.all([
                            google.maps.importLibrary('maps'),
                            google.maps.importLibrary('places'),
                            google.maps.importLibrary('geocoding'),
                            google.maps.importLibrary('marker'),
                            google.maps.importLibrary('geometry')
                        ]);
                    }
                    await window.OpenCities.__mapsLibsPromise;

                    if (window.OpenCities?.GoogleMapsLoader) {
                        window.OpenCities.GoogleMapsLoader._fire();
                    }
                } catch (err) {
                    console.error('Google Maps failed to initialise', err);
                }
            })();
        </script>
    
    <script src="/files/templates/00000000-0000-0000-0000-000000000000/cb43379f-eba5-4cd1-93a4-8079e117411e/v/249/modernizr.custom.710f3bf.js?seamlessts=639124142685437828" defer></script>
    
    <!--// End Framework Section -->
    <!-- OpenCities Section -->
    <script>
        var OpenCities = OpenCities || {};
        OpenCities.Paths = {
            SiteTemplate: '/files/templates/00000000-0000-0000-0000-000000000000/cb43379f-eba5-4cd1-93a4-8079e117411e/v/249/',
            ThemePath: '/files/templates/00000000-0000-0000-0000-000000000000/cb43379f-eba5-4cd1-93a4-8079e117411e/v/249/'
        };
    </script>
    <script src='/ocapi/dbd07518-637e-482b-b929-a9c9eed79ca7/en-US/websitesettings.js'></script>
    <script src="/files/templates/00000000-0000-0000-0000-000000000000/cb43379f-eba5-4cd1-93a4-8079e117411e/v/249/oc_head.js?applied=20250929055040"></script>
    <!-- Script Combine. To enter debug mode for this browser session, enter OcScriptCombineDebug=true as a querystring -->
<link href="/files/oc-templates/00000000-0000-0000-0000-000000000000/cb43379f-eba5-4cd1-93a4-8079e117411e/v/249/oc_grid.css~oc_grid_s1.css~oc_style.css~oc_wizard_style.css~oc_main.css~oc_forms.css~oc_wizard.css~oc_wizard_menu.css~oc_main_s1.css~oc_wizard_s1.css~oc_wizard_menu_s1.css~OcScriptCombine_Minify0?uniqueid=20250929055040" rel="stylesheet" type="text/css">
    <!-- Script Combine. To enter debug mode for this browser session, enter OcScriptCombineDebug=true as a querystring -->
<link href="/files/oc-templates/00000000-0000-0000-0000-000000000000/cb43379f-eba5-4cd1-93a4-8079e117411e/v/249/client_style.css~client.css~client_menu.css~client_s1.css~client_menu_s1.css~client_forms.css~OcScriptCombine_Minify0?uniqueid=20250929055040" rel="stylesheet" type="text/css">
    <script>
(function (BackgroundSettings, $, undefined) {
    BackgroundSettings.initialise = function () {
        this.Application = {"CSSSelector":".content-outer-container","EnableFade":false};
    };
} (OpenCities.BackgroundSettings = OpenCities.BackgroundSettings || {}, jQuery));
OpenCities.BackgroundSettings.initialise();
</script>
    
    <!-- Script Combine. To enter debug mode for this browser session, enter OcScriptCombineDebug=true as a querystring -->
<link href="/files/oc-templates/00000000-0000-0000-0000-000000000000/cb43379f-eba5-4cd1-93a4-8079e117411e/v/249/oc_print.css~client_print.css~OcScriptCombine_Minify0?uniqueid=20250929055040" rel="stylesheet" type="text/css" media="print">
    <!-- Script Combine. To enter debug mode for this browser session, enter OcScriptCombineDebug=true as a querystring -->
<script src="/files/oc-templates/00000000-0000-0000-0000-000000000000/cb43379f-eba5-4cd1-93a4-8079e117411e/v/249/external_plugins.js~oc_form_helper.js~oc_main.js~plugins.js~oc_main_init.js~OcScriptCombine_Minify0?uniqueid=20250929055040" defer="true"></script>
    <style>
.toolbar-link-list ul li:first-child a {color: #ffcc00 !important;}
</style>
<script type="text/javascript">
    window._monsido = window._monsido || {
        token: "lSHJOigyU0pps-HdexhHxA",
        statistics: {
            enabled: true,
            cookieLessTracking: false,
            documentTracking: {
                enabled: false,
                documentCls: "monsido_download",
                documentIgnoreCls: "monsido_ignore_download",
                documentExt: [],
            },
        },
        pageAssistV2: {
            enabled: true,
            theme: "light",
            mainColor: "#000080",
            textColor: "#ffffff",
            linkColor: "#252525",
            buttonHoverColor: "#41596b",
            mainDarkColor: "#052942",
            textDarkColor: "#ffffff",
            linkColorDark: "#FFCF4B",
            buttonHoverDarkColor: "#FFCF4B",
            greeting: "Discover your personalization options",
            direction: "leftbottom",
            coordinates: "unset unset 3 20",
            iconShape: "circle",
            title: "Personalization Options",
            titleText: "Welcome to PageAssist™ toolbar! Adjust the options below to cater the website to your accessibility needs.",
            iconPictureUrl: "logo",
            logoPictureUrl: "https://res.cloudinary.com/dpqp2pvqp/image/upload/v1668702047/doral-logo2_xhl24o.png",
            logoPictureBase64: "",
            languages: ["en-US", "pt-PT", "es-MX"],
            defaultLanguage: "en-US",
            skipTo: false,
            alwaysOnTop: false,
        },
    };
</script>
<script type="text/javascript" async src="https://app-script.monsido.com/v2/monsido-script.js"></script>
    
</head>
<body class="body layout-modern  site-search-always-visble  content-type-oc-general content-template-oc-full-width group-template-oc-full-width-with-default-header page-name-page-not-found page-sequence-17 page-depth-1 page-section-17 website-type-primary device-desktop " id="body-top">
    <form name="mainForm" method="post" action="/Government-Center/ak.m" id="mainForm">
<div>
<input type="hidden" name="ctl04_seamless_script_manager_TSM" id="ctl04_seamless_script_manager_TSM" value="" />
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__SEAMLESSVIEWSTATE" id="__SEAMLESSVIEWSTATE" value="H4sIAAAAAAAEAAHwBw/4X9x+IUGz/Xz6wwmlruQ9D50kWGOhosBa2waVe7j1XJFspo6arsulRMwKNOsu96ErXN/fXEb8u5sf31ceHCp9A/Vkdx+TUpgI3zFsO0Y62/Zpsj503UzU2cyq04sbpH6hLqx3JloATZfd493UfJo0yVNxT8rlM6tkH6S//LiCxUBx+CpiU4RgcMZe7N7kssWI4NFlb13Tm6nEATh+EVoLUQ0+fytarS0Lft8x2uz9cjRYS0zqK5U6gnuTWSRckQz96KxdLf0IDAs53R34FGQt1TOPttVowPcgRzffU9x7mz6r7pNHitebrU0WsoNnyUAHAVIYTmTPPvnnAznDFdMFbw5tIGr8TcyEbJCBRxvKTqIerGtums20xuqkRZ6zim8js7NG32Dopwhf+8981zD1x7piQghixPp3TGmvsEXhj8LUYZsbTDGTQDDysASD188UWL/GYcJzVmGVy//B8R1OlPlWJV3h8F/nSMjBjCMNAOZehxz+7xW3AGmj94No7z/xdTZ8RY3VGZUBxcnXWLnovifZoTh7CJ6SVU5LvD/0p3EU9HBsZRE82CIvAYlVDZoZPpzdYH5Jkmv8wu+vSJ492j8luQPVO0ScfeTfkFDSZTmMUUvbkB028kWsxrL3DuPweesTy4RQzTX3sjjfF1ibnebAnu86JCOMuoEY5Ui25XptdxrDImAbfjvz+pC4rUhOHOKrhHRgI4MagJXNSeShaWGA2uoHkc1OUGv3IrnFnwhP9h1sTPxgxYxwEAIQce6nEQ8SjlDkhU/howA3qmd/Me3CFbjWjCLjO5dQk4GZ1qFajdL4HSyZKmB8CF9SlH5DEvnn94CXb3EGr6rlxbuH0qOf2/oiXN0WTCbT8Z3oowU0zXu2nCHEA49PJvNKTSnaHIS04VuDE1rvCbjTNvYabiXVOARZ54yec49n5N7VuPyROOUhDBt6HKL/scF4+vKkxqwNfaFJbA9T/PoKn4J8vYrP8ZGoVH81iRCKkuB/aVsEfEJC2kirlvocE8sw8EbMt6jQOlrsClAA0M8fpuGt6oKR2+rFsIAiP+zlIoIy475ophOpYnnDr91Q1LAyJEdvMYE7v/rOfQluXc/EZu1rCNhZThYyzzB7Mlr2D7D3HUC0fwQEC+/2mPDtMbh3/O5WRq/A/pdk/bjBGTPcZtqt4FlAThVzIE8dx6PklzS2Qtaj0UAYZVKjjWiA++JWl9AAKUuowXlAT8rmZPHo8mNJDh0dJjtHvD9TVSKjup99gVbMYJ6AXuBK5R6NEomdFpkbWg6DPwUwuTMWiMQhkXfHngc7woHR4gCs2a92QQ3xjSkwJPejyAFWZn4Qhajm8i0lHwXI93FVJdWElYia7fmJD0CnBxnjTMqlkZ8468SkrnFLxQdrGLz3ksrmIhZfRqGpYH9FZdUJLXkGcrIiXA6ON67xraRdDZPek+977YnGRnrLdeNwu4kSk3o4bH+ipcmruxtUoa/4kuTM7/FVnorM/y9ytxnh64l4+ObTX+pgvak95DXvRaOjbYBEPTlprwQ68dGMTUiOgNXEqinzlK/l+fA29vRQzJNpLIRTMcdidX/BR2biTH82t8nz8OEcXnhtO9uDK7P7tKz+nh5SxGLdCMClG7Wgquh92pqYgj4hbdriYulxYhms4UMcTMR7G1s+Y3Gpf+v+7pYX+Bganr/0xxl2ropVpTTqOdwvdd1BGatAe2J5sAibQ9TMm0gyTp3rsp7wTyVV8g4MHGGlN9pgYFjCu1JqE7aDHeOY+qkaa1kG3AYYdWYdbfErVREv5x8f4YqOAD+nb4ENy4vogckrspo9QgBtH4Kt4ZrmTUW3/oEPmAcy0af3/hZyTvFpDm/Le70VjIpxHVLs667Rwz2wqWx98HcYzFb+z2kXiJRws32Mn+VPBrIge4aZJsAEnsddtyWRcvITqY/eBeN/YQ0IpXeVA87VOLwQ5KYTq8BLp76AzpjHMWqsnvDDp99WZS7RTaEvH/YwIjCrAX1ubuTqg2QgyWsWGLRkDuEss6Sp5ngyLtAJIh2+zDZF8cLWpIvHbJa8efgLhbck8uwGiaaaM1PmVQa79CN0NJ+a4Di6t+WacxZzRvw+OBrHlmVXesbkl0tlRsX4SiXNsN0rTKCMbONggvr/9Av2VC8V/60e/ONOqOUk2poPOViE/dm/p9vJRDC2BdZ6eha3ZRH2OQDH+wwscX+IxZzVVjtM1CmKhzlcFQZzoHyjdMY1o5qpvQgt4bF0Lx54liS/tY50t3MwzfWlELiqn6LlOih/ICf94Eb2KzuWfsTxanpjHayqzMUHNwBOwpn5hoIi1oh+QSjyR/nc8zJMlNSembfpWFYGpIoREYabZdmxgSdWqPJxVN98dYyADFrPC/W4SkqjSAEebNZTa4XqzvPfdnYkdWXTgNH1AbVS2/m93gKIJWJVyYG2hSC5TPT+Gm9+Z7RmyrlypR77swXU25uu9nPiF7ToLlVOD8a+AKjqEwFmqTIGWxAqTy1Kxh9vvLm0PvvLpXwPTifRfw2AOEW5YTdwOqMJiD8Xfc6gmBbibeIg1D11rnB+hmnpXK2e7OrYie4c7F/xK/k8oVF7UwlVFyCqvysj/vHRL8jmVd28lz2qZgij51gMPyCVDFrdlI3m5XPOMyEGW/tRckmYinkPViaMIInMzlfwU1PlXwmDFNVJCaDv1tmdHCaxNP0ThfNKZLfOwRywaB813LrwBwAA" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['mainForm'];
if (!theForm) {
    theForm = document.mainForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=L6sm7a6eFOt9D7tu04RnBzP65uxZ284gdjpoDbU37dmUvw4bsKyWFQQLCEXuYd4rZhJa-Zp-Prlw4YXbQD6CQ2gcRjGBOZdtGt986c-RkJs1&amp;t=638901392248157332" type="text/javascript"></script>


<script src="/Telerik.Web.UI.WebResource.axd?_TSM_HiddenField_=ctl04_seamless_script_manager_TSM&amp;compress=1&amp;_TSM_CombinedScripts_=%3b%3bSystem.Web.Extensions%2c+Version%3d4.0.0.0%2c+Culture%3dneutral%2c+PublicKeyToken%3d31bf3856ad364e35%3aen-GB%3aa8328cc8-0a99-4e41-8fe3-b58afac64e45%3aea597d4b%3ab25378d2" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=BAIm7rHck4qvt-1nI0boBeTLRL4I2o9XJbX2D8wINUoEqb6s4zmQvsLPM-p5_1iaH4ah2JBFT6-kQfwGCFNy2UnRCC2PhJTCuUouHqd7bM_BmMr-4Vt2ZT01umA9xTF_ywYMMnSrtdi1A4ifmp1gwVPMKh4h-Qsevv0zcG3WgE_C3LwAnbOegnnSf2Nz_TjUOFJqeQ2vv0P5Q7yTZzhG_y1ZzUidW_LF4n6c5XdUOM3V5iFKHXxmLWscP4crhSNAWkc82y1pd69Hlyhwf5dfPJcx-2hfZQJeQPjlca3Ot9zh2g7YEGiB7hs1BCg0YUabEE-Sc1QtUsHJarcvfHNHi8NpIbrHo99y0pCTOvwhDYe-GBNEa6w2wqc-CvA-7NpZnAOMesuJpUPVkBcMDiGkrizmyE9vwhNWFkXlKQcH5Yj8O4lSGkJs2V-_Lg3moqgW0" type="text/javascript"></script>
<script src="/Telerik.Web.UI.WebResource.axd?_TSM_HiddenField_=ctl04_seamless_script_manager_TSM&amp;compress=1&amp;_TSM_CombinedScripts_=%3b%3bOpenCities.CustomControls%3aen-GB%3a5da10c8e-b64d-411a-8c8c-af154c09df97%3a8e1d32bf" type="text/javascript"></script>
    <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl04$seamless_script_manager', 'mainForm', [], [], [], 90, '');
//]]>
</script>

<script type="text/javascript">
    try{
        function SeamlessEndRequestHandler(sender, args) {
            try {
                var dataItems = args.get_dataItems();
                if(dataItems.ctl04_seamless_script_manager)
                    document.getElementById('__SEAMLESSVIEWSTATE').value = dataItems.ctl04_seamless_script_manager;
            }
            catch (e) { }
        }

        Sys.WebForms.PageRequestManager.getInstance().add_endRequest(SeamlessEndRequestHandler);
    }
    catch (e) { }
</script>

    <div class="unsupported-browser-warning js-element"></div>
    
    <div hidden>
        <span id="new-window-0">opens in new tab or window </span>
    </div>
    <div class="overlay-container"></div>
    
    <div class="background-container">
        <div class="page-container">
            <!-- OC Layout Element GROUP TEMPLATE -->
            <!--groupTemplateStart--><div id="skip-to-content-container">
        <a href='#main-content' class="visuallyhidden focusable" id='skip-to-content-link'>Skip to main content</a>
    </div><header>
            <div class="toolbar-outer-container">
  <div class="toolbar-inner-container clearfix">
    <div class="toolbar-item toolbar-quicklinks toolbar-display-dropdown">
	<button type="button" aria-controls="toolbar-quicklinks-drop-down" aria-expanded="false" class="toolbar-button toolbar-button-quicklinks js-element"><span>Quick Links</span><i aria-hidden="true"></i></button>	
	<div id="toolbar-quicklinks-drop-down" class="toolbar-drop-down toolbar-quicklinks-drop-down clearfix">
		<ul>
		  <li><a href="https://www.cityofdoral.com/Elected-officials/Christi-Fraga/Doral-at-the-Center-of-G20" class="oc-icon-b oc-i--none link-type-internal"><span>G20</span></a></li><li><a href="https://www.cityofdoral.com/Government-Center/Office-of-the-City-Clerk/Council-Meetings" class="oc-icon-b oc-i--none link-type-internal"><span>City Meetings</span></a></li><li><a href="https://www.cityofdoral.com/Elected-officials" class="oc-icon-b oc-i--none link-type-internal"><span>Elected Officials</span></a></li><li><a href="https://doralfl.attract.neogov.com/p/careers" class="oc-icon-b oc-i--none link-type-external" target="_blank"><span>Jobs</span></a></li>
		</ul>
	</div>
</div><div class="toolbar-item toolbar-language notranslate toolbar-display-dropdown"><div class="no-js-element">
		  <ul>
		    <li id="toolbar-language-option-en-us" role="option" aria-selected="true"><a href="https://www.cityofdoral.com/Page-Not-Found?oc_lang=en-US" class="lang-item lang-en-us" data-translate-to="en-us" lang="en-US">English (United States)<span class="visuallyhidden"> Select this as your preferred language</span></a></li>
          </ul>
		</div>
	<button type="button" role="combobox" aria-controls="toolbar-language-drop-down" aria-expanded="false" aria-haspopup="listbox" aria-autocomplete="none" aria-labelledby="toolbar-language-label" class="toolbar-button toolbar-button-language js-element">  
        <span id="toolbar-language-label" class="current-language">
            Select a language to translate to
		</span>
		<i aria-hidden="true"></i>
	</button>
	<div id="toolbar-language-drop-down" role="listbox" aria-label="Available languages" class="toolbar-drop-down toolbar-language-drop-down js-element clearfix">
		<ul>
		    <li id="toolbar-language-option-en-us" role="option" aria-selected="true"><a href="https://www.cityofdoral.com/Page-Not-Found?oc_lang=en-US" class="lang-item lang-en-us" data-translate-to="en-us" lang="en-US">English (United States)<span class="visuallyhidden"> Select this as your preferred language</span></a></li>
        </ul>
	</div></div>
  </div>
</div>
            <div class="header-outer-container">
    <div class="header-container header-layout-4  clearfix">
			<div class="header-site-logo">
				<a href="https://www.cityofdoral.com/Home" lang="en-US" aria-label="City of Doral - Home - Logo">
				</a>
			</div>
      
		    <div class="mobile-search-btn js-element">
		        <button><i aria-hidden="true"></i><span class="mobile-search-btn-text"><span class="visuallyhidden">Open </span>Search</span></button>
		    </div>
		    <div class="header-website-settings">
                <button id="btn-mob-nav" type="button" aria-expanded="false" aria-controls="nav">
                    <i aria-hidden="true"></i><span class="side-menu-btn-text">Menu</span>
                </button>
        	</div>
          <div class="navigation-outer-container">
	<div id="nav" role="navigation" class="navigation-container  navigation-container-option-8" data-menu-type="horizontal" aria-label="primary">
        <div class="grid">
            <div class="col-xs-12">              
                <ul class="sf-menu" id="sc-main-menu"><li class="nav-section-quarters-1   first-item nav-item-seq-1">
<a href="https://www.cityofdoral.com/About" class="nav-level-1 nav-has-children"  target="">
	<i class="item-icon" aria-hidden="true"></i><span class="item-text">About</span>
</a>
<button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow" aria-controls="sc-menu-second-level">
              <i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-second-level">

          
            <li class=" "><a  href="https://www.cityofdoral.com/About/Doral-Facts" class=""  target="">Doral Facts</a></li><li class=" "><a  href="https://www.cityofdoral.com/About/Doral-History" class=""  target="">Doral History</a></li></ul></li>
          
            <li class="nav-section-quarters-1   nav-item-seq-2">
<a href="https://www.cityofdoral.com/Businesses" class="nav-level-1 nav-has-children"  target="">Businesses</a>
<button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow" aria-controls="sc-menu-second-level">
              <i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-second-level">

          
            <li class=" "><a  href="https://www.cityofdoral.com/Businesses/Economic-Development-Reports" class=""  target="">Economic Development Reports</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/Local-Discounts" class=""  target="">Promote Your Business</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/Get-Recognized" class=""  target="">Get Recognized</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/Access-Business-Support" class=""  target="">Access Business Support</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/Plan-a-Grand-Opening" class=""  target="">Plan a Grand Opening</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/Connect-with-Partners" class=""  target="">Connect with Partners</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/Doral-Décor-District" class=""  target="">Doral Décor District</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/Downtown-Doral-Arts-District" class=""  target="">Downtown Doral Arts District</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/Sister-Cities-Program" class=""  target="">Sister Cities Program</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/Doral-GIS-Info-Portal" class=""  target="_blank">Doral GIS Info Portal</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/Sponsorship-Opportunities" class=""  target="_blank">Sponsorship Opportunities</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/Business-Mailing-List" class=""  target="">Business Mailing List</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/New-Businesses" class=""  target="">New Businesses</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/Doral-at-a-Glance" class=""  target="">Doral at a Glance</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/Commercial-Property-Search" class=""  target="">Commercial Property Search</a></li><li class=" "><a  href="https://www.cityofdoral.com/Businesses/Starting-a-Business-in-Doral" class=""  target="">Starting a Business in Doral</a></li></ul></li>
          
            <li class="nav-section-quarters-2   nav-item-seq-3">
<a href="https://www.cityofdoral.com/Departments" class="nav-level-1 nav-has-children"  target="">Departments</a>
<button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow" aria-controls="sc-menu-second-level">
              <i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-second-level">

          
            <li class=" "><a  href="https://www.cityofdoral.com/Departments/City-Attorneys-Office" class=""  target="_self">City Attorney's Office</a></li><li class=" "><a  href="https://www.cityofdoral.com/Departments/City-Clerks-Office" class=""  target="_self">City Clerk's Office</a></li><li class=" "><a  href="https://www.cityofdoral.com/Departments/City-Managers-Office" class=""  target="_self">City Manager's Office</a></li><li class=" "><a  href="https://www.cityofdoral.com/Departments/Development-Services" class=""  target="_self">Development Services</a></li><li class=" "><a  href="https://www.cityofdoral.com/Departments/Building-Department" class="nav-has-children"  target="">Building Department</a><button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow-child" aria-controls="sc-menu-third-level"><i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-third-level">
          
            <li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Announcements-and-Updates"  target="">Announcements and Updates</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Building-Recertification-Program"  target="">Building Recertification Program</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Complaints"  target="">Complaints</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Contractor-Registration"  target="">Contractor Registration</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Directory"  target="">Directory</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Documents"  target="">Documents</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Fee-Schedule"  target="">Fee Schedule</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Frequently-Asked-Questions"  target="">Frequently Asked Questions</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Flood-Information"  target="">Flood Information</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Helpful-Links"  target="">Helpful Links</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Inspections-and-Route-Info"  target="">Inspections and Route Info</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/MeetQ"  target="">MeetQ</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/New-Business-Information"  target="">New Business Information</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/New-Homeowner-Information"  target="">New Homeowner Information</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Outdoor-Dining-Requirements"  target="">Outdoor Dining Requirements</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Permit-Fee-Utilization-Report"  target="">Permit Fee Utilization Report</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Permit-Submittal-Checklists"  target="">Permit Submittal Checklists</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Permit-Submittal-Guidelines"  target="">Permit Submittal Guidelines</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Private-Provider-Guidelines"  target="">Private Provider Guidelines</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Records-Request"  target="">Records Request</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Building-Department/Videos-and-Tutorial-Guides"  target="">Videos and Tutorial Guides</a></li></ul></li><li class=" "><a  href="https://www.cityofdoral.com/Departments/Code-Compliance-Department" class="nav-has-children"  target="">Code Compliance Department</a><button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow-child" aria-controls="sc-menu-third-level"><i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-third-level">
          
            <li  class=" "><a href="https://www.cityofdoral.com/Departments/Code-Compliance-Department/Code-Violation-Lien-Searches"  target="">Code Violation Lien Searches</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Code-Compliance-Department/Directory"  target="">Directory</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Code-Compliance-Department/Documents"  target="">Documents</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Code-Compliance-Department/Frequently-Asked-Questions"  target="">Frequently Asked Questions</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Code-Compliance-Department/If-you-receive-a-code-violation"  target="">If you receive a code violation</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Code-Compliance-Department/Keep-Doral-Beautiful-Award"  target="">Keep Doral Beautiful Award</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Code-Compliance-Department/Mayors-Citizens-Government-Academy"  target="">Mayor's Citizens Government Academy</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Code-Compliance-Department/Outreach-Activities"  target="">Outreach Activities</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Code-Compliance-Department/Registration-of-Defaulted-Mortgaged-Property"  target="">Registration of Defaulted Mortgaged Property</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Code-Compliance-Department/Report-a-Concern"  target="">Report a Concern</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Code-Compliance-Department/Short-Term-Vacation-Rental-Ordinance-FAQs"  target="">Short-Term Vacation Rental Ordinance FAQs</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Code-Compliance-Department/Special-Magistrate"  target="">Special Magistrate</a></li></ul></li><li class=" "><a  href="https://www.cityofdoral.com/Departments/Finance-Department" class="nav-has-children"  target="">Finance Department</a><button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow-child" aria-controls="sc-menu-third-level"><i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-third-level">
          
            <li  class=" "><a href="https://www.cityofdoral.com/Departments/Finance-Department/Awards"  target="">Awards: Government Finance Officers Association</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Finance-Department/Budget-in-Brief"  target="">Budget in Brief</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Finance-Department/Annual-Financial-Reports"  target="">Annual Financial Reports</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Finance-Department/City-Budget"  target="">City Budget</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Finance-Department/Directory"  target="">Directory</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Finance-Department/Transparency-Portal"  target="">Transparency Portal</a></li></ul></li><li class=" "><a  href="https://www.cityofdoral.com/Departments/Human-Resources" class="nav-has-children"  target="">Human Resources</a><button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow-child" aria-controls="sc-menu-third-level"><i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-third-level">
          
            <li  class=" "><a href="https://www.cityofdoral.com/Departments/Human-Resources/Why-Doral"  target="_blank">Why Doral?</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Human-Resources/Collective-Bargaining-Agreements"  target="">Collective Bargaining Agreements</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Human-Resources/Job-Opportunities"  target="_blank">Job Opportunities</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Human-Resources/Pay-and-Classification-Plan"  target="">Pay & Classification Plan</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Human-Resources/Policies-and-Procedures"  target="">Policies and Procedures</a></li></ul></li><li class=" "><a  href="https://www.cityofdoral.com/Departments/Information-Technology" class="nav-has-children"  target="">Information Technology</a><button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow-child" aria-controls="sc-menu-third-level"><i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-third-level">
          
            <li  class=" "><a href="https://www.cityofdoral.com/Departments/Information-Technology/Awards"  target="">Awards</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Information-Technology/Essential-IT-Capabilities"  target="">Essential IT Capabilities</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Information-Technology/Residents-Engagement-and-Digital-City-Initiatives"  target="">Residents Engagement and Digital City Initiatives</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Information-Technology/Technology-Innovative-Community"  target="">Technology Innovative Community</a></li></ul></li><li class=" "><a  href="https://www.cityofdoral.com/Departments/Parks-and-Recreation" class="nav-has-children"  target="">Parks & Recreation</a><button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow-child" aria-controls="sc-menu-third-level"><i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-third-level">
          
            <li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Adopt-a-Garden-Program"  target="">Adopt-a-Garden Program</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Adult-and-Teens-Programs"  target="">Adult and Teens Programs</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Adult-Sports"  target="">Adult Sports</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Call-for-Student-Filmmakers"  target="">Call for Student Filmmakers</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Call-for-Photographers-2026"  target="">Call for Photographers: Capture Doral</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Camps"  target="">Camps</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Directory"  target="">Directory</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Documents"  target="">Documents</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Event-Vendors"  target="">Event Vendors</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Fitness-Center-Classes-and-Memberships"  target="">Fitness Center Classes and Memberships</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Mailing-List"  target="">Mailing List</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Master-Plan"  target="">Master Plan</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Memberships-Benefits"  target="">Memberships & Benefits</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/New-Kayak-Kiosks-Now-Available"  target="">New Kayak Kiosks Now Available!</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Parks-and-Facilities"  target="">Parks and Facilities</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Private-Swim-Lessons"  target="">Private Swim Lessons</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Program-Registration-Launch"  target="_self">Program Registration Launch</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Publications"  target="">Publications</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Refund-Policy"  target="">Refund Policy</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Silver-Club"  target="">Silver Club</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Special-Events"  target="">Special Events</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Special-Needs-Programs"  target="">Special Needs Programs</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Sponsorship-Opportunities"  target="">Sponsorship Opportunities</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Step-Up-Doral-Programs"  target="">Step Up Doral Programs</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Swim-Lessons-Winter-2026"  target="">Swim Lessons - Winter 2026</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Volunteers"  target="">Volunteers</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Youth-Programs"  target="">Youth Programs</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Youth-Sports"  target="">Youth Sports</a></li></ul></li><li class=" "><a  href="https://www.cityofdoral.com/Departments/Police-Department" class="nav-has-children"  target="">Police Department</a><button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow-child" aria-controls="sc-menu-third-level"><i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-third-level">
          
            <li  class=" "><a href="https://www.cityofdoral.com/Departments/Police-Department/Camping-Ordinance-Resources"  target="">Camping Ordinance & Resources</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Police-Department/Citizens-Police-Academy"  target="">Citizens Police Academy</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Police-Department/Command-Staff"  target="">Command Staff</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Police-Department/Commendations-Complaints"  target="">Commendations & Complaints</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Police-Department/Connect-Doral"  target="">Connect Doral</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Police-Department/Crime-Mapping"  target="">Crime Mapping</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Police-Department/Documents"  target="">Documents</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Police-Department/Emergency-Preparedness"  target="">Emergency Preparedness</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Police-Department/Job-Opportunities"  target="_blank">Job Opportunities</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Police-Department/Property-and-Evidence"  target="">Property and Evidence</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Police-Department/Special-Needs-Registry"  target="">Special Needs Registry</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Police-Department/Speeding-Cameras-in-School-Zones"  target="">Speeding Cameras in School Zones</a></li></ul></li><li class=" "><a  href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department" class="nav-has-children"  target="">Planning and Zoning Department</a><button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow-child" aria-controls="sc-menu-third-level"><i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-third-level">
          
            <li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/BTR-Payment-Schedule-Sample"  target="">BTR Payment Schedule Sample</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Business-License-Process"  target="">Business License Process</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Business-License-Division"  target="">Business License Division</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Business-Tax-Receipt-Quick-Pay"  target="">Business Tax Receipt Quick Pay</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Certificate-of-Use-for-Foreclosed-Properties"  target="">Certificate of Use for Foreclosed Properties</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Comprehensive-Plan"  target="">Comprehensive Plan</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Development-Population-Stats"  target="">Development - Population Stats</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Development-Review-Application-and-Forms"  target="">Development Review Application and Forms</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Development-Review-Process"  target="">Development Review Process</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Directory"  target="">Directory</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Documents"  target="">Documents</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Future-Land-Use-Map"  target="">Future Land Use Map</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/General-information"  target="">General information</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Green-Re-use-Redevelopment"  target="">Green Re-use Redevelopment</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Housing-Masterplan"  target="">Housing Masterplan</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Illustrative-Zoning-Guide"  target="">Illustrative Zoning Guide</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Land-Use-Documents"  target="">Land Use Documents</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Official-Zoning-Map"  target="">Official Zoning Map</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Public-Arts-Program"  target="">Public Arts Program</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/School-Concurrency"  target="">School Concurrency</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Special-Events-Permits"  target="">Special Events Permits</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Planning-and-Zoning-Department/Studies-and-Master-Plans"  target="">Studies and Master Plans</a></li></ul></li><li class=" "><a  href="https://www.cityofdoral.com/Departments/Procurement-and-Asset-Management-Department" class="nav-has-children"  target="">Procurement and Asset Management Department</a><button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow-child" aria-controls="sc-menu-third-level"><i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-third-level">
          
            <li  class=" "><a href="https://www.cityofdoral.com/Departments/Procurement-and-Asset-Management-Department/Active-Solicitations-2026"  target="">Active Solicitations 2026</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Procurement-and-Asset-Management-Department/Active-Solicitations-2025"  target="">Active Solicitations 2025</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Procurement-and-Asset-Management-Department/Active-Solicitations-2024"  target="">Active Solicitations 2024</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Procurement-and-Asset-Management-Department/Bid-Notifications"  target="">Bid Notifications</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Procurement-and-Asset-Management-Department/Cone-of-Silence"  target="">Cone of Silence</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Procurement-and-Asset-Management-Department/Formal-Bid-Process"  target="">Formal Bid Process</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Procurement-and-Asset-Management-Department/How-to-do-Business-with-City-of-Doral"  target="">How to do Business with City of Doral</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Procurement-and-Asset-Management-Department/Solicitations-2021-2023"  target="">Solicitations 2021 - 2023</a></li></ul></li><li class=" "><a  href="https://www.cityofdoral.com/Departments/Public-Affairs-Department" class="nav-has-children"  target="">Public Affairs Department</a><button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow-child" aria-controls="sc-menu-third-level"><i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-third-level">
          
            <li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Affairs-Department/Directory"  target="">Directory</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Affairs-Department/Photo-Video-Disclaimer"  target="">Photo-Video Disclaimer</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Affairs-Department/Request-for-Use-of-Facility"  target="">Request for Use of Facility</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Affairs-Department/Social-Media-Disclaimer"  target="">Social Media Disclaimer</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Affairs-Department/Web-Accessibility-WCAG"  target="">Web Accessibility WCAG</a></li></ul></li><li class=" "><a  href="https://www.cityofdoral.com/Departments/Public-Works-Department" class="nav-has-children"  target="">Public Works Department</a><button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow-child" aria-controls="sc-menu-third-level"><i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-third-level">
          
            <li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Adopt-A-Street"  target="">Adopt-A-Street</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Composting-Program"  target="">Composting Program</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Directory"  target="">Directory</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Documents"  target="">Documents</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Doral-Trolley"  target="">Doral Trolley</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Frequently-Asked-Questions"  target="">Frequently Asked Questions</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Green-Initiatives"  target="">Green Initiatives</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Helpful-Links"  target="">Helpful Links</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Master-Plans"  target="">Master Plans</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Parking-in-Doral"  target="">Parking in Doral</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Permit-Procedures"  target="">Permit Procedures</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Solid-Waste"  target="">Solid Waste</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Storm-Preparedness-of-Urban-Forest"  target="">Storm Preparedness of Urban Forest</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Stormwater-Utility-Division"  target="">Stormwater Utility Division</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Summer-Irrigation-Tips"  target="">Summer Irrigation Tips</a></li><li  class=" "><a href="https://www.cityofdoral.com/Departments/Public-Works-Department/Tree-Permits"  target="">Tree Permits</a></li></ul></li></ul></li>
          
            <li class="nav-section-quarters-2   nav-item-seq-4">
<a href="https://www.cityofdoral.com/Residents" class="nav-level-1 nav-has-children"  target="">Residents</a>
<button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow" aria-controls="sc-menu-second-level">
              <i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-second-level">

          
            <li class=" "><a  href="https://www.cityofdoral.com/Residents/BlastingMining-Information" class=""  target="">Blasting/Mining Information</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/City-of-Doral-App" class=""  target="">City of Doral App</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/City-of-Doral-Emergency-Hardship-Grant-for-Families" class=""  target="">City of Doral Emergency Hardship Grant for Families (EHG4F)</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/Community-Development-Districts-Information" class=""  target="">Community Development Districts Information</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/move-the-incinerator" class=""  target="">Help us move the Incinerator out of Doral</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/Department-Phone-Numbers" class=""  target="">Department Phone Numbers</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/Doral-Alerts" class=""  target="_blank">Doral Alerts</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/Doral-Life" class=""  target="">Doral Life</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/Doral-TV-Channel-77" class=""  target="">Doral TV - Channel 77</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/Feedback" class=""  target="">Feedback</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/Freebee-in-Doral" class=""  target="">Freebee in Doral</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/GIS-Portal-redirect" class=""  target="_blank">GIS Portal</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/Odor-Monitoring-Services" class=""  target="">Odor Monitoring Services</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/Online-Services" class=""  target="_self">Online Services</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/Party-Rentals" class=""  target="_self">Party Rentals</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/Sign-Up-for-Our-Newsletter" class=""  target="">Sign Up for Our Newsletter</a></li><li class=" "><a  href="https://www.cityofdoral.com/Residents/Special-Needs-Resource-Directory" class=""  target="">Special Needs Resource Directory</a></li></ul></li>
          
            <li class="nav-section-quarters-3   nav-item-seq-5">
<a href="https://www.cityofdoral.com/Visitors" class="nav-level-1 nav-has-children"  target="">Visitors</a>
<button aria-label="Expand" aria-haspopup="true" class="mobnav-subarrow" aria-controls="sc-menu-second-level">
              <i aria-hidden="true"></i>
              </button>
<ul id="sc-menu-second-level">

          
            <li class=" "><a  href="https://www.cityofdoral.com/Visitors/Hotels-in-Doral" class=""  target="">Hotels in Doral</a></li><li class=" "><a  href="https://www.cityofdoral.com/Visitors/Parks-and-Facilities" class=""  target="_self">Parks and Facilities</a></li><li class=" "><a  href="https://www.cityofdoral.com/Visitors/Ritmo-Doral" class=""  target="">Ritmo Doral</a></li><li class=" "><a  href="https://www.cityofdoral.com/Visitors/Shopping-in-Doral" class=""  target="">Shopping in Doral</a></li></ul></li>
          
            </ul>
            </div>
        </div>
    </div>
</div>
			
			<div class="header-search-control-container" id="header-search">
				<div class="search-inner-container">
					<div class="sc-search-panel" onkeypress="javascript:return WebForm_FireDefaultButton(event, &#39;ctl08_btnSearch&#39;)">
	<label for="ctl08_txtSearch" id="ctl08_lblSearch" class="sc-search-label">Search</label><input name="ctl08$txtSearch" type="text" id="ctl08_txtSearch" class="sc-search-text" placeholder="How can we help you?" /><input type="submit" name="ctl08$btnSearch" value="Search" id="ctl08_btnSearch" class="sc-search-button" />
</div>
					<div role="status" id="predictiveResults"></div>
				</div>
			</div>
    </div>
</div>

            
            </header>
            <div class="content-outer-container">
                <div id="main" role="main" class="main-outer-container clearfix">
                        
                        <div class="content-main-container">
                            <div class="grid">
					            <div class="col-xs-12">
						            <nav id="breadcrumbs-container" aria-label="You Are Here :">
							            <span role="list">
<span role="listitem">
	<a href="https://www.cityofdoral.com/Home"  lang="en-US">Home</a>
	<span class="nav-separator" aria-hidden="true" role="presentation">/</span>
</span>
          <span class="current-page" role="listitem" aria-current="page" >Page Not Found</span></span>
						            </nav>
					            </div>
                      
					            <div class="col-xs-12">
						            <div class="main-inner-container">
							            <div id="main-content" class="main-container clearfix">
							              
                            <!-- OC Layout Element Conent Template -->
							              <!--normalTemplateStart--><div class="grid">
    <div class="col-xs-12">
        <h1 class='oc-page-title '>Page Not Found</h1>
        
        
        <div><img alt='Page not found image' src='/files/content/city/v/1/page-not-found/page-not-found-icon.png'></div><p style="margin-top: 40px;">We can't seem to find the page you are looking for.</p><p style='font-size: 20px; '><a href='https://www.cityofdoral.com/Home' target='_self'>Go back to the home page</a></p>
      
        
            
        
    </div>
    
    
</div><!--normalTemplateEnd-->
                            
                            
                            
							            </div>
						            </div>
					            </div>
                        
                            </div>
                        </div>
                        <div class="back-to-top-container text-center">
                            <a href="#body-top" id="back-to-top"><i aria-hidden="true"></i><span class="js-visuallyhidden">Back to top</span></a>
                        </div>
                </div>
            </div><!--groupTemplateEnd-->
            <footer>
                
                    <div class="footer-outer-container footer-first-row">
                        <div class="footer-container clearfix">
                            <div class="grid grid-pad">
                                <div class="col-xs-12 col-s-6 col-m-3 col-lg-3 contact-us-widget" >
	<h3 class="footer-title">Contact Us</h3>
	<p><strong>City of Doral</strong></p>
<p>8401 NW 53rd Terrace</p>
<p>Doral, Florida 33166</p>
<p><a href="https://maps.app.goo.gl/HAPNUPD1MbJYfjk38" target="_blank">View on Map</a></p>
<p><a href="tel:305-593-6725">Phone: 305-593-6725</a></p>


	
	
</div><div class="col-xs-12 col-s-6 col-m-3 col-lg-3 quick-links-widget" >
	<h3 class="footer-title">Quick Links</h3>
	
	<ul class="footer-links without-icons ">  <li>
<a href="https://www.cityofdoral.com/Departments/Procurement-and-Asset-Management-Department/Active-Solicitations-2025" target="_self"  >Active Solicitations</a>
</li>
          <li>
<a href="https://www.cityofdoral.com/Departments/Building-Department/Flood-Information" target="_self"  >Flood Information</a>
</li>
          <li>
<a href="https://www.cityofdoral.com/Online-Services" target="_self"  >Online Services</a>
</li>
          <li>
<a href="https://www.cityofdoral.com/Government-Center/Office-of-the-City-Manager/Transparency" target="_self"  >Transparency</a>
</li>
          <li>
<a href="https://www.cityofdoral.com/Departments/Procurement-and-Asset-Management-Department/Bid-Notifications" target="_self"  >Vendor Registration</a>
</li>
           </ul>
	
</div><div class="col-xs-12 col-s-6 col-m-3 col-lg-3 get-involved-widget" >
	<h3 class="footer-title">Get Involved</h3>
	
	<ul class="footer-links without-icons ">  <li>
<a href="https://www.cityofdoral.com/Departments/Human-Resources/Job-Opportunities" target="_blank"  >Job Opportunities</a>
</li>
          <li>
<a href="https://www.cityofdoral.com/Government-Center/Office-of-the-City-Clerk/Council-Meetings" target="_self"  >Council Meetings</a>
</li>
          <li>
<a href="https://www.cityofdoral.com/Government-Center/Office-of-the-City-Clerk/Election-Information" target="_self"  >Elections Information</a>
</li>
          <li>
<a href="https://www.cityofdoral.com/Departments/Parks-and-Recreation/Event-Vendors" target="_self"  >Become a Sponsor</a>
</li>
           </ul>
	
</div><div class="col-xs-12 col-s-6 col-m-3 col-lg-3 share-connect-widget" >
	<h3 class="footer-title">Share &amp; Connect</h3>
	
	<ul class="footer-links with-icons social-media-links">  <li class="footer-link-x">
	<a href="https://twitter.com/cityofdoral" target="_blank"  >
<i aria-hidden="true"></i>X
</a>
</li>
          <li class="footer-link-facebook">
	<a href="https://facebook.com/cityofdoral" target="_blank"  >
<i aria-hidden="true"></i>Facebook
</a>
</li>
          <li class="footer-link-youtube">
	<a href="https://youtube.com/user/DoralTV77" target="_blank"  >
<i aria-hidden="true"></i>YouTube
</a>
</li>
          <li class="footer-link-instagram">
	<a href="https://instagram.com/cityofdoral/" target="_blank"  >
<i aria-hidden="true"></i>Instagram
</a>
</li>
          <li class="footer-link-">
	<a href="https://www.cityofdoral.com/Residents/Sign-Up-for-Our-Newsletter" target="_blank"  >
<i aria-hidden="true"></i>Subscribe to our Newsletter
</a>
</li>
           </ul>
	
</div>
                            </div>
                        </div>
                    </div>
                
                <div class="footer-outer-container footer-second-row">
                    <div class="footer-container clearfix">
                        <div class="grid grid-pad footer-secondary-links">
                            <div class="col-xs-12 col-m-7">
                                
                                    <div><a href="https://www.cityofdoral.com/Departments/Public-Affairs-Department/Web-Accessibility-WCAG" target="_self"  >Web Accessibility WCAG</a>&nbsp;| <a href="https://www.cityofdoral.com/Privacy-Policy" target="_self"  >Privacy Statement</a>&nbsp;| <a href="https://www.cityofdoral.com/Site-Map" target="_self"  >Sitemap</a>&nbsp;| <a href="https://www.cityofdoral.com/A-Z-Index" target="_self"  >A - Z Index</a></div>
                                
                            </div>
                            <div class="col-xs-12 col-m-5 powered-by">
                                <div class="right">
                                    &copy; 2026 City of Doral&nbsp;|&nbsp;<span class="powered-by">Powered by <a href="https://granicus.com/solution/govaccess/opencities/" target="_blank">Granicus</a></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <script src="/files/oc-resources/b9015858-988c-48a4-9473-7c193df083e4/JsTextSnippets.js?ocsvclang=en-US" type="text/javascript"></script><script></script>
    
    // Adds Flag Icons to the Translate Function
<script>
$(document).ready(function() {
    // Add flags to all language links based on class
    $('.lang-en-us').prepend('🇺🇸 ');
    $('.lang-es').prepend('🇪🇸 ');

    // Add flag to current language based on text content
    var currentText = $('.current-language').text().trim();
    if (currentText === 'English (United States)') {
        $('.current-language').prepend('🇺🇸 ');
    } else if (currentText === 'Spanish') {
        $('.current-language').prepend('🇪🇸 ');
    }
});
</script>
<style>
.oc-emergency-announcement-container .side-box {
	padding:17px 18px 0px 22px !important;
	text-align:center;	
	}
.oc-emergency-announcement-container .side-box .side-box-title {
	font-size:1.4em;
}
</style>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZW2SDKHF6L"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'G-ZW2SDKHF6L');
</script>
<script>
(function() {
  if (typeof gtag !== 'function') return;
  const thresholds = [25, 50, 75, 90];
  const fired = new Set();

  function send(pct) {
    if (fired.has(pct)) return;
    fired.add(pct);
    gtag('event', 'scroll_depth', {
      percent_scrolled: pct,
      page_path: location.pathname
    });
  }

  function onScroll() {
    const doc = document.documentElement;
    const scrollTop = doc.scrollTop || document.body.scrollTop;
    const scrollHeight = doc.scrollHeight - doc.clientHeight;
    if (scrollHeight <= 0) return;
    const pct = Math.round((scrollTop / scrollHeight) * 100);
    thresholds.forEach(t => { if (pct >= t) send(t); });
  }

  window.addEventListener('scroll', onScroll, { passive: true });
})();
</script>
    
    

<script type="text/javascript">
//<![CDATA[
window.__TsmHiddenField = $get('ctl04_seamless_script_manager_TSM');//]]>
</script>
</form>
</body>
</html>